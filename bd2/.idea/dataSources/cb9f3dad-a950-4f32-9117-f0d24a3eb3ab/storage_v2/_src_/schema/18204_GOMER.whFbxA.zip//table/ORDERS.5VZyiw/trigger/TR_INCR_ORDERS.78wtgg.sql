create trigger TR_INCR_ORDERS
    before insert
    on ORDERS
    for each row
BEGIN
        SELECT sq_orders.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

