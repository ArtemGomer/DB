create trigger TR_ADD_GOODS_TYPE
    before insert
    on ORDERS
    for each row
DECLARE
            cnt INTEGER;
        BEGIN
            SELECT COUNT(*) INTO cnt FROM GOODS_TYPE WHERE type = :NEW.type;
            IF cnt = 0 THEN
                INSERT INTO GOODS_TYPE(type) VALUES(:NEW.type);
            END IF;
        END;
/

