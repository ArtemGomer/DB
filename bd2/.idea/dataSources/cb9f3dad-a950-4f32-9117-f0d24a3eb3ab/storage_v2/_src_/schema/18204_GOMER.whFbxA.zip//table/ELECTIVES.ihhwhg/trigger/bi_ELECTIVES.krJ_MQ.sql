create trigger "bi_ELECTIVES"
    before insert
    on ELECTIVES
    for each row
begin  
  if :new."ELECTIVE_NAME" is null then
    select "ELECTIVES_SEQ".nextval into :new."ELECTIVE_NAME" from dual;
  end if;
end;
/

