create trigger "bi_GROUPS"
    before insert
    on GROUPS
    for each row
begin  
  if :new."GROUP_NUMBER" is null then
    select "GROUPS_SEQ".nextval into :new."GROUP_NUMBER" from dual;
  end if;
end;
/

