create trigger TR_INCR_DELIVERED_GOODS
    before insert
    on DELIVERED_GOODS
    for each row
BEGIN
        SELECT sq_delivered_goods.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

