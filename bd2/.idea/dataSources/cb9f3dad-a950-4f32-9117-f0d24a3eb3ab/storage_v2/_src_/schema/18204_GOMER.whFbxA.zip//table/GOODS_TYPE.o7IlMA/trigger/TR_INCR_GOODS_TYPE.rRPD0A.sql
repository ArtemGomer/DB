create trigger TR_INCR_GOODS_TYPE
    before insert
    on GOODS_TYPE
    for each row
BEGIN
        SELECT sq_goods_type.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

