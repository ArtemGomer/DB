create trigger TR_INCR_DELIVERS
    before insert
    on DELIVERS
    for each row
BEGIN
        SELECT sq_delivers.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

