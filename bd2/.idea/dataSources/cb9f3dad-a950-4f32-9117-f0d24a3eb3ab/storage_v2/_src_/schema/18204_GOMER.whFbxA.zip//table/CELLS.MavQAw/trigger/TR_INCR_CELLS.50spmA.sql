create trigger TR_INCR_CELLS
    before insert
    on CELLS
    for each row
BEGIN
            SELECT sq_cells.NEXTVAL
            INTO :NEW.id
            FROM dual;
        END;
/

