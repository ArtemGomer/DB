create trigger TR_INCR_FEE
    before insert
    on FEE
    for each row
BEGIN
        SELECT sq_fee.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

