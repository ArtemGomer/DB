create trigger "bi_STUDENTS"
    before insert
    on STUDENTS
    for each row
begin  
  if :new."STUDENT_ID" is null then
    select "STUDENTS_SEQ".nextval into :new."STUDENT_ID" from dual;
  end if;
end;
/

