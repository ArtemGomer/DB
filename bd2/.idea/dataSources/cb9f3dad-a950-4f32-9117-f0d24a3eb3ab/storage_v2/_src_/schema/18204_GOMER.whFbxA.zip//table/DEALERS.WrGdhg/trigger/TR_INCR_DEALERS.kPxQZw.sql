create trigger TR_INCR_DEALERS
    before insert
    on DEALERS
    for each row
BEGIN
        SELECT sq_dealers.NEXTVAL
        INTO :NEW.id
        FROM dual;
    END;
/

